function caesarCipher(text, shift) {
  let finalText = "";

  for (let i = 0; i < text.length; i++) {
    let char = text[i];

    if (char >= "A" && char <= "Z") {
      let code = char.charCodeAt(0);
      let newCode = ((code - 65 + shift + 26) % 26) + 65;
      finalText += String.fromCharCode(newCode);
    }

    else if (char >= "a" && char <= "z") {
      let code = char.charCodeAt(0);
      let newCode = ((code - 97 + shift + 26) % 26) + 97;
      finalText += String.fromCharCode(newCode);
    }

    else {
      finalText += char;
    }
  }

  return finalText;
}

function encryptMessage() {
  let message = document.getElementById("message").value;
  let key = Number(document.getElementById("key").value);

  let encryptedText = caesarCipher(message, key);

  document.getElementById("encrypted").innerText = encryptedText;
}

function decryptMessage() {
  let encryptedText = document.getElementById("encrypted").innerText;
  let key = Number(document.getElementById("key").value);

  let decryptedText = caesarCipher(encryptedText, -key);

  document.getElementById("decrypted").innerText = decryptedText;
}

function clearAll() {
  document.getElementById("message").value = "";
  document.getElementById("key").value = 3;
  document.getElementById("encrypted").innerText = "";
  document.getElementById("decrypted").innerText = "";
}